System.register(["__unresolved_0", "cc", "__unresolved_1"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, instantiate, Node, Prefab, Vec3, Label, PlayerController, _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _crd, ccclass, property, BlockType, GameState, GameManager;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'proposal-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfPlayerController(extras) {
    _reporterNs.report("PlayerController", "./PlayerController", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      instantiate = _cc.instantiate;
      Node = _cc.Node;
      Prefab = _cc.Prefab;
      Vec3 = _cc.Vec3;
      Label = _cc.Label;
    }, function (_unresolved_2) {
      PlayerController = _unresolved_2.PlayerController;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "aa4ccn3HuJPsoV7Opk6AB7D", "GameManager", undefined);

      __checkObsolete__(['_decorator', 'Component', 'instantiate', 'Node', 'Prefab', 'Vec3', 'Label']);

      ({
        ccclass,
        property
      } = _decorator);

      (function (BlockType) {
        BlockType[BlockType["BT_NONE"] = 0] = "BT_NONE";
        BlockType[BlockType["BT_STONE"] = 1] = "BT_STONE";
      })(BlockType || (BlockType = {}));

      ;

      (function (GameState) {
        GameState[GameState["GS_INIT"] = 0] = "GS_INIT";
        GameState[GameState["GS_PLAYING"] = 1] = "GS_PLAYING";
        GameState[GameState["GS_END"] = 2] = "GS_END";
      })(GameState || (GameState = {}));

      ;

      _export("GameManager", GameManager = (_dec = ccclass('GameManager'), _dec2 = property({
        type: Prefab
      }), _dec3 = property({
        type: _crd && PlayerController === void 0 ? (_reportPossibleCrUseOfPlayerController({
          error: Error()
        }), PlayerController) : PlayerController
      }), _dec4 = property({
        type: Node
      }), _dec5 = property({
        type: Node
      }), _dec6 = property({
        type: Node
      }), _dec7 = property({
        type: Label
      }), _dec(_class = (_class2 = class GameManager extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "cubePrfb", _descriptor, this);

          _initializerDefineProperty(this, "playerCtrl", _descriptor2, this);

          _initializerDefineProperty(this, "startMenu", _descriptor3, this);

          _initializerDefineProperty(this, "oneStep", _descriptor4, this);

          _initializerDefineProperty(this, "twoStep", _descriptor5, this);

          this.roadLength = 50;
          this._road = [];

          _initializerDefineProperty(this, "stepsLabel", _descriptor6, this);
        }

        start() {
          var _this$playerCtrl;

          //current state is initiliazation
          this.curState = GameState.GS_INIT;
          (_this$playerCtrl = this.playerCtrl) == null ? void 0 : _this$playerCtrl.node.on("JumpEnd", this.onPlayerJumpEnd, this);
        }

        onPlayerJumpEnd(moveIndex) {
          if (this.stepsLabel) {
            //casting to string from number, make sure we always score up to 50
            this.stepsLabel.string = '' + (moveIndex >= this.roadLength ? this.roadLength : moveIndex);
          }

          this.checkResult(moveIndex);
        }

        init() {
          if (this.startMenu) {
            //the menu is true and not null
            this.startMenu.active = true; //enables it 
          } //disabling buttons


          if (this.oneStep) {
            this.oneStep.active = false;
          }

          if (this.twoStep) {
            this.twoStep.active = false;
          }

          this.generateRoad(); //generate road

          if (this.playerCtrl) {
            //switch off mouse input
            this.playerCtrl.setInputActive(false); //reset player position to 0,0,0

            this.playerCtrl.node.setPosition(Vec3.ZERO);
            this.playerCtrl.reset(); //moveIndex = 0
          }
        }

        set curState(value) {
          switch (value) {
            case GameState.GS_INIT:
              this.init(); //execute initialisation

              break;

            case GameState.GS_PLAYING:
              if (this.startMenu) {
                //disables the start menu
                this.startMenu.active = false;
              }

              if (this.stepsLabel) {
                //reset to zero at the start of play
                this.stepsLabel.string = '0';
              }

              setTimeout(() => {
                if (this.playerCtrl) {
                  //enable the input
                  this.playerCtrl.setInputActive(true);
                }
              }, 0.1); //enable a small delay
              //ENABLING THE BUTTONS

              if (this.oneStep) {
                this.oneStep.active = true;
              }

              if (this.twoStep) {
                this.twoStep.active = true;
              }

              break;

            case GameState.GS_END:
              break;
          }
        }

        onStartButtonClicked() {
          this.curState = GameState.GS_PLAYING;
        }

        checkResult(moveIndex) {
          //player position is not at beyond the end of the road
          if (moveIndex < this.roadLength) {
            //check if the player is not on a road
            if (this._road[moveIndex] == BlockType.BT_NONE) {
              this.curState = GameState.GS_INIT;
            }
          } else {
            //player is beyond the road
            this.curState = GameState.GS_INIT;
          }
        }

        generateRoad() {
          //PRevent using old track
          this.node.removeAllChildren();
          this._road = []; //First position has to be a stone

          this._road.push(BlockType.BT_STONE);

          for (let i = 1; i < this.roadLength; i++) {
            //if the previous position is an empty space
            if (this._road[i - 1] === BlockType.BT_NONE) {
              //then this position has to be a stone 1
              this._road.push(BlockType.BT_STONE);
            } else {
              //randomize between 0 and 1
              this._road.push(Math.floor(Math.random() * 2));
            }
          } //Generate tracks based on the runway


          for (let j = 0; j < this._road.length; j++) {
            let block = this.spawnBlockByType(this._road[j]);

            if (block) {
              this.node.addChild(block);
              block.setPosition(j, -1.5, 0);
            }
          }
        }

        spawnBlockByType(type) {
          if (!this.cubePrfb) {
            return null;
          }

          let block = null; //we can generate the road for real roads (1)

          switch (type) {
            case BlockType.BT_STONE:
              //instantiate block
              block = instantiate(this.cubePrfb);
              break;
          }

          return block;
        }

        update(deltaTime) {}

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "cubePrfb", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "playerCtrl", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "startMenu", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "oneStep", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "twoStep", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "stepsLabel", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=a6e4e975b65c5d1a791fbe663598552c58efadb0.js.map