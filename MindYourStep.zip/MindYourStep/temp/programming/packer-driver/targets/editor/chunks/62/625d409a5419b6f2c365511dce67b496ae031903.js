System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, input, Input, Vec3, _dec, _class, _crd, ccclass, property, PlayerController;

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      input = _cc.input;
      Input = _cc.Input;
      Vec3 = _cc.Vec3;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "3dc0f7EmZ9NKpd3mHnwhtdT", "PlayerController", undefined);

      __checkObsolete__(['_decorator', 'Component', 'EventMouse', 'input', 'Input', 'Node', 'Vec3']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("PlayerController", PlayerController = (_dec = ccclass('PlayerController'), _dec(_class = class PlayerController extends Component {
        constructor(...args) {
          super(...args);
          this._startJump = false;
          this._jumpStep = 0;
          this._curPos = new Vec3();
          this._targetPos = new Vec3();
          this._jumpTime = 0;
          this._curJumpSpeed = 0;
          this._curJumpTime = 0;
        }

        start() {
          //listen for click event
          input.on(Input.EventType.MOUSE_UP, this.onMouseUp, this);
        }

        onMouseUp(event) {
          //check if the user clicked the left (0) or the right (2) mouse button
          if (event.getButton() === 0) //checks for left
            {} else if (event.getButton() === 2) //checks for right
            {}
        }

        jumpByStep(step) {
          if (this._startJump) //if the player is already jumping
            {
              return; // then we make sure the function does not make another jump
            } //the following code only runs if the player is not jumping currently


          this._startJump = true; //so that no other jump runs together

          this._jumpStep = step; // based on left or right click

          this._curJumpTime = 0; // Reset Jump time

          this._curJumpSpeed = this._jumpStep / this._jumpTime; // current jump step

          this.node.getPosition(this._curPos); //get the position of the player

          Vec3.add(this._targetPos, this._curPos, new Vec3(this._jumpStep, 0, 0));
        }

        update(deltaTime) {
          if (this._startJump) // if _startJump is true
            {}
        }

      }) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=625d409a5419b6f2c365511dce67b496ae031903.js.map