System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, input, Input, _dec, _class, _crd, ccclass, property, PlayerController;

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      input = _cc.input;
      Input = _cc.Input;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "3dc0f7EmZ9NKpd3mHnwhtdT", "PlayerController", undefined);

      __checkObsolete__(['_decorator', 'Component', 'EventMouse', 'input', 'Input', 'Node']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("PlayerController", PlayerController = (_dec = ccclass('PlayerController'), _dec(_class = class PlayerController extends Component {
        constructor(...args) {
          super(...args);
          this._startJump = false;
          this._jumpStep = 0;
        }

        start() {
          //listen for click event
          input.on(Input.EventType.MOUSE_UP, this.onMouseUp, this);
        }

        onMouseUp(event) {
          //check if the user clicked the left (0) or the right (2) mouse button
          if (event.getButton() === 0) //checks for left
            {} else if (event.getButton() === 2) //checks for right
            {}
        }

        jumpByStep(step) {}

        update(deltaTime) {
          if (this._startJump) // if _startJump is true
            {}
        }

      }) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=b40bf54b4a2b8c6687d31d9967a21ba671735add.js.map