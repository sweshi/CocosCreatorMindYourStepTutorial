/// <reference path="C:\ProgramData\cocos\editors\3.7.1\resources\resources\3d\engine\@types\jsb.d.ts"/>
